const $=id=>document.getElementById(id);let platform='小红书',result=null,sessionId=sessionStorage.getItem('yx-session')||'',currentTrace=[],demoProduct='',modelReady=false;
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeLink=x=>{try{const u=new URL(x);return u.protocol==='https:'?esc(u.href):'#';}catch{return '#';}};
const labels={supported:'支持',unsupported:'不支持',conflict:'冲突',pending:'待确认',pass:'通过'};
const formatTime=x=>x?new Date(x).toLocaleString('zh-CN'):'未记录';
const sourceTypes={official:'华为官网',official_web:'华为官网',local:'本地资料',demo:'Demo模拟资料（非官方事实）',ima:'ima',local_index:'本地图片索引',local_image_index:'本地图片索引（仅外观/配色）'};
const issueText=x=>typeof x==='string'?x:[x.location,x.message||x.reason||x.code].filter(Boolean).join(' · ');
document.querySelectorAll('[data-revision]').forEach(x=>x.onclick=()=>{$('revision').value=x.dataset.revision;$('revision').focus();});
function selectPlatform(p){platform=p;document.querySelectorAll('[data-platform]').forEach(x=>x.classList.toggle('selected',x.dataset.platform===p));}
document.querySelectorAll('[data-platform]').forEach(x=>x.onclick=()=>selectPlatform(x.dataset.platform));
const examples={student:['为华为 MateBook 14 鸿蒙版生成针对大学新生的小红书开学推荐，重点关注日常学习和选购前的软件核对。','小红书'],work:['为华为 MateBook 14 鸿蒙版生成针对经常出差的职场用户的公众号文章，关注差旅、文档与会议场景。','微信公众号'],creator:['为华为 MateBook 14 鸿蒙版生成面向摄影爱好者的内容创作小红书，关注照片展示和选购前软件核对，不编造性能测试。','小红书'],family:['为华为 MateBook 14 鸿蒙版生成面向家庭换新用户的公众号选购说明，关注家人日常使用与旧资料迁移前需确认的问题。','微信公众号'],enterprise:['为华为 MateBook 14 鸿蒙版生成企业采购公众号说明，面向行政采购，关注岗位应用核对和小范围试点，不承诺企业权益。','微信公众号'],launch:['为华为 MateBook 14 鸿蒙版生成新品首发小红书，面向关注新品的职场用户，先核实新品身份，没有旧款证据就不做升级比较。','小红书'],holiday:['为华为 MateBook 14 鸿蒙版生成节日送礼朋友圈，面向为家人选电脑的用户，不写优惠、价格和库存。','门店朋友圈'],store:['为华为 MateBook 14 鸿蒙版生成门店到访海报，面向准备换电脑的职场用户，突出可现场体验的屏幕卖点。','门店海报']};
document.querySelectorAll('[data-example]').forEach(x=>x.onclick=()=>{const [text,p]=examples[x.dataset.example];$('task').value=demoText(text);$('revision').value='';$('product').value=demoProduct;selectPlatform(p);});
const initialOutput=$('output').innerHTML,initialInsights=$('insights').innerHTML;
function exportsEnabled(on){for(const id of ['copy','markdown','html'])$(id).disabled=!on;}
$('reset').onclick=()=>{sessionId='';sessionStorage.removeItem('yx-session');result=null;$('revisionTools').hidden=true;currentTrace=[];$('task').value='';$('revision').value='';$('product').value=demoProduct;$('output').innerHTML=initialOutput;$('insights').innerHTML=initialInsights;$('generate').firstChild.textContent='✦ 生成营销图文 ';$('resultStatus').textContent='已开启新的创作会话';$('trace').textContent='尚未执行任务';$('progress').textContent='';$('error').hidden=true;exportsEnabled(false);document.querySelectorAll('#pipeline span').forEach(x=>x.className='');};
$('output').addEventListener('click',e=>{if(e.target.closest('[data-restore]')&&result){render();$('resultStatus').textContent='上一审核通过版本 · 本次修改未交付';$('progress').textContent='可调整修改要求后继续';}});
function showError(s){$('error').hidden=false;$('error').textContent=s;}
function showStage(stage,decision){$('progress').textContent='✦ '+stage+'…';const items=[...document.querySelectorAll('#pipeline span')];const index=items.findIndex(x=>x.textContent===stage);items.forEach((x,i)=>x.className=i<index?'done':i===index?'active':'');if(decision){currentTrace.push(decision);renderTrace();}}
function renderTrace(){const tr=currentTrace.length?currentTrace:result?.trace||[];$('trace').innerHTML=tr.map(e=>`<div class="trace-item"><b>${esc(e.stage)} · ${esc(e.action)}</b><p>${esc(e.summary)}</p>${e.query?`<small>查询：${esc(e.query)}${e.purpose?' · '+esc(e.purpose):''}</small>`:''}${e.hits?`<small>命中：${e.hits.map(x=>esc(x.id+' '+x.topic)).join('、')||'无'}</small>`:''}${e.issues?.length?`<small>${e.issues.map(esc).join('；')}</small>`:''}</div>`).join('')||'尚未执行任务';}
function demoText(text){return demoProduct?text.replace(/华为 MateBook 14 鸿蒙版/g,demoProduct):text;}
async function apiFetch(url,options){
 const response=await fetch(url,options);
 if(response.status===401){window.location.replace('/login');throw Error('访问会话已失效，请重新登录');}
 return response;
}
$('logout').onclick=async()=>{
 try{const response=await apiFetch('/api/auth/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});if(!response.ok)throw Error('退出失败，请重试');sessionStorage.removeItem('yx-session');window.location.replace('/login');}
 catch(e){showError(e.message);}
};
async function boot(){
 $('generate').disabled=true;
 try{
  const healthResponse=await apiFetch('/api/health'),health=await healthResponse.json();
  if(!healthResponse.ok)throw Error(health.error||'无法读取服务状态');
  $('sourceChip').textContent='✦ DeepSeek Flash × '+health.source;
  $('identityStatus').textContent=health.identity?.label||'本机创作会话（无需云端账号）';
  $('sourceStatus').textContent=health.source+' · '+(health.mode==='demo'?'演示内容不可视为官方产品事实':'按任务检索；来源与读取时间随证据展示');
  $('connection').textContent=health.source+' × DeepSeek'+(health.keyConfigured?' 已就绪':' 未配置密钥');
  const response=await apiFetch('/api/products'),data=await response.json();
  if(!response.ok)throw Error(data.error);
  for(const p of data.products){const o=document.createElement('option');o.value=o.textContent=p;$('product').append(o);}
  if(health.mode==='demo'){
   demoProduct=data.products[0]||'';
   $('task').value=demoText($('task').value);$('product').value=demoProduct;
  }
  const access=await fetch('/api/auth/status').then(r=>r.json());$('logout').hidden=!access.required;
  if(sessionId){
   const response=await apiFetch('/api/sessions/'+encodeURIComponent(sessionId));
   if(response.ok){result=await response.json();currentTrace=result.trace||[];$('task').value=result.request?.task||('为'+result.task.product+'面向'+result.task.audience+'创作'+result.task.platform+'内容');$('product').value=result.task.product;selectPlatform(result.task.platform);render();renderTrace();}
   else{sessionId='';sessionStorage.removeItem('yx-session');}
  }
  modelReady=health.keyConfigured===true;
  if(!modelReady)showError('服务端未配置 DeepSeek 密钥，请联系维护者配置后刷新页面。可先查看界面与示例，暂不能生成。');
  $('generate').disabled=!modelReady;
 }catch(e){showError(e.message);}
}
function article(){return MarketingContent.article(result);}
function renderInsights(r){const d=r.draft,strategy=d?.strategy||r.strategy||{},v=r.verification||{};$('insights').innerHTML=`<section class="insight-block"><div class="block-label">◎ 任务理解</div><p>${esc(r.task?.audience)} · ${esc(r.task?.scene)}<br>阶段：${esc(r.task?.stage)}<br>目标：${esc(r.task?.goal)}</p><ul>${(r.task?.painPoints||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></section><section class="insight-block"><div class="block-label">✧ 先规划，后创作</div><h4>人群洞察与切入</h4><p>${esc(strategy.audienceInsight)}</p><p>${esc(strategy.angle)}</p><h4>策略卖点假设（成稿以证据为准）</h4><ul>${(strategy.priorities||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><h4>结构与行动引导</h4><p>${(strategy.outline||[]).map(esc).join(' → ')}</p><p>${esc(strategy.ctaReason)}</p>${r.changes?`<h4>当前修改范围</h4><p>${esc(r.changes.summary)}<br>改动：${(r.changes.changedSections||[]).map(esc).join('、')||'无'}<br>保持：${(r.changes.unchangedSections||[]).map(esc).join('、')||'无'}</p>`:''}</section><section class="insight-block"><div class="block-label">▤ 本次实际取证 · ${(r.evidence||[]).length}条</div><p>${esc(r.provenance?.library||r.source)}</p>${(r.evidence||[]).map(e=>`<details class="evidence"><summary>${esc(e.id+' · '+e.topic)} ${e.kind==='guidance'?'（场景参考）':''}</summary><p>${esc(sourceTypes[e.sourceType]||e.sourceType||'来源未分类')} · ${esc(e.document)}<br>${esc(e.product||'场景参考')}<br>${esc(e.relativePath||e.url||'')}<br>资料日期：${esc(e.sourceDate||'未标注')}<br>获取时间：${esc(formatTime(e.retrievedAt))}<br>适用配置：${esc(e.configuration||e.condition||'详见原文')}</p><pre>${esc(e.quote)}</pre>${e.source?`<a href="${safeLink(e.source)}" target="_blank" rel="noopener noreferrer">原始来源页 ↗</a>`:''}</details>`).join('')}<h4>图片来源</h4>${(r.images||[]).map(i=>`<details class="evidence"><summary>${esc(i.id+' · '+i.caption)}</summary><p>${esc(i.name)}<br>${esc(i.model)}<br>${esc(i.relativePath)}<br>${esc(sourceTypes[i.sourceType]||i.sourceType||'图片索引')} · ${esc(formatTime(i.retrievedAt))}<br>${esc(i.selectionReason||'')}</p><a href="${safeLink(i.source)}" target="_blank" rel="noopener noreferrer">来源页 ↗</a></details>`).join('')}</section><section class="insight-block"><div class="block-label">✓ 独立审核</div><p><span class="badge ${v.status!=='pass'?'risk':''}">${esc(labels[v.status]||v.status||'未审核')}</span> ${v.independent?'LLM辅助＋规则':''}</p>${(v.claims||[]).map(c=>`<details class="evidence claim-${esc(c.status)}"><summary>${esc(c.id)} · ${esc(labels[c.status]||c.status)} · ${esc(c.location)}</summary><p>${esc(c.text)}</p><p>证据：${c.evidenceIds.map(esc).join('、')||'无'}<br>${esc(c.conditions)}<br>${esc(c.reason)}</p></details>`).join('')}${(v.conflicts||[]).map(x=>`<p class="warning">来源冲突：${esc(issueText(x))} · ${esc((x.evidenceIds||[]).join('、'))}</p>`).join('')}${(v.imageChecks||[]).map(x=>`<p>图片 ${esc(x.id)} · ${esc(labels[x.status]||x.status)}：${esc(x.reason)}</p>`).join('')}${(v.issues||[]).map(x=>`<p>⚠ ${esc(issueText(x))}</p>`).join('')}${(v.notes||[]).map(x=>`<p>${esc(x)}</p>`).join('')}</section>`;}
function render(){$('revisionTools').hidden=false;$('generate').firstChild.textContent='✦ 修改并重新核验 ';$('connection').textContent=result.provenance.library+' × DeepSeek';$('output').innerHTML=article();$('platformLabel').textContent=result.task.platform;$('resultStatus').textContent=`版本 ${result.version} · 独立审核通过 · ${result.verification.claims.length}项陈述`;renderInsights(result);exportsEnabled(result.publishable===true);}
$('form').onsubmit=async e=>{e.preventDefault();$('error').hidden=true;$('generate').disabled=true;exportsEnabled(false);currentTrace=[];$('trace').textContent='准备执行任务';$('output').classList.add('loading');$('progress').textContent='连接Agent…';$('resultStatus').textContent=result?'生成新版本；下方暂留上一稿':'执行中…';try{const response=await apiFetch('/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({task:$('task').value,revision:$('revision').value,product:$('product').value,platform,sessionId:sessionId||undefined})});if(!response.ok){const err=await response.json();throw Error(err.error||'请求失败');}const reader=response.body.getReader(),decoder=new TextDecoder();let pending='',received=false;while(true){const {value,done}=await reader.read();pending+=decoder.decode(value||new Uint8Array(),{stream:!done});let at;while((at=pending.indexOf('\n'))>=0){const line=pending.slice(0,at);pending=pending.slice(at+1);if(!line)continue;const event=JSON.parse(line);if(event.type==='stage')showStage(event.stage,event.decision);if(event.type==='error')throw Error(event.error);if(event.type==='result'){received=true;const r=event.result;if(r.sessionId){sessionId=r.sessionId;sessionStorage.setItem('yx-session',sessionId);}if(r.status==='complete'){result=r;currentTrace=r.trace;render();renderTrace();$('progress').textContent='✓ 新版本已交付';}else{$('output').innerHTML=`<div class="question"><span class="badge risk">${r.status==='blocked'?'已暂停交付':'需要补充信息'}</span><h3>${r.status==='blocked'?'证据或核验未满足发布条件':'补充关键需求后继续'}</h3><ul>${(r.questions||[]).map(q=>`<li>${esc(q)}</li>`).join('')}</ul><p>未发布不合格候选稿；请调整需求或核对资料后继续。</p>${result?'<button type="button" data-restore>查看上一审核通过稿</button>':''}</div>`;$('resultStatus').textContent=r.status==='blocked'?'未发布 · 禁止复制与导出':'等待补充';renderInsights(r);$('revisionTools').hidden=!result;exportsEnabled(false);$('progress').textContent=r.status==='blocked'?'任务已暂停，保留上一审核通过的会话版本':'请补充必要信息';}}}if(done)break;}if(!received)throw Error('响应提前中断，未收到完成结果');}catch(e){showError(e.message);$('progress').textContent='本次未完成，请重试';$('resultStatus').textContent=result?'本次未完成；下方为上次版本':'任务未完成';if(result){$('output').innerHTML=article();exportsEnabled(true);}}finally{$('generate').disabled=!modelReady;$('output').classList.remove('loading');}};
function text(){return MarketingContent.text(result);}
function download(name,data,type){const url=URL.createObjectURL(new Blob([data],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText(text());$('copy').textContent='已复制';setTimeout(()=>$('copy').textContent='复制',1500);}catch{showError('复制失败，请选中正文复制');}};
async function imageData(){
 const pairs=await Promise.all(result.draft.imagePlan.map(async plan=>{
  const img=result.images.find(i=>i.id===plan.id);if(!img)throw Error('配图不存在');
  const r=await apiFetch(img.url);if(!r.ok)throw Error('无法读取图片'+img.id);
  const blob=await r.blob();if(!['image/png','image/jpeg'].includes(blob.type))throw Error('图片格式不支持');
  const data=await new Promise((ok,no)=>{const f=new FileReader();f.onload=()=>ok(f.result);f.onerror=no;f.readAsDataURL(blob);});
  return [img.id,data];
 }));return Object.fromEntries(pairs);
}
async function exportFile(format){
 const snapshot=result,b=$(format);b.disabled=true;
 try{const data=await imageData();if(result!==snapshot)throw Error('稿件已更新，请重新导出');
  if(format==='markdown'){download('营销图文.md',MarketingContent.markdown(snapshot,data),'text/markdown;charset=utf-8');}
  else{const css=await fetch('/style.css');if(!css.ok)throw Error('无法读取导出样式');download('营销图文.html',MarketingContent.html(snapshot,await css.text(),data),'text/html;charset=utf-8');}
  $('progress').textContent='✓ '+(format==='markdown'?'Markdown':'HTML')+' 已导出（内嵌图片）';
 }catch(e){showError('导出失败：'+e.message);}finally{b.disabled=!result?.publishable;}
}
$('markdown').onclick=()=>exportFile('markdown');
$('html').onclick=()=>exportFile('html');
boot();
