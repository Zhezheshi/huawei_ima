const {test}=require('node:test'),assert=require('node:assert/strict');
const {configure}=require('../src/server-config.cjs');

test('默认仍仅监听本机且保持精确Host/Origin限制',()=>{
 const c=configure({});assert.equal(c.host,'127.0.0.1');assert.ok(c.hosts.has('127.0.0.1:3210'));assert.ok(!c.hosts.has('evil.invalid'));assert.ok(!c.origins.has('https://evil.invalid'));assert.equal(c.password,'');
});
test('公网模式缺口令或HTTPS源时拒绝启动',()=>{
 for(const env of [{HOST:'0.0.0.0'},{HOST:'0.0.0.0',APP_ORIGIN:'https://test.invalid',APP_PASSWORD:'short'},{HOST:'0.0.0.0',APP_ORIGIN:'http://test.invalid',APP_PASSWORD:'nonsecret-long-test-password'},{APP_ORIGIN:'https://test.invalid/path'},{APP_ORIGIN:'https://user:password@test.invalid'}])assert.throws(()=>configure(env));
});
test('容器来源和嵌入来源均按精确HTTPS来源校验，不信任通配或脚本',()=>{
 const c=configure({HOST:'0.0.0.0',PORT:'7860',APP_ORIGIN:'https://review.invalid',APP_PASSWORD:'nonsecret-test-password',APP_FRAME_ANCESTORS:'https://modelscope.cn https://www.modelscope.cn'});
 assert.ok(c.hosts.has('review.invalid'));assert.ok(!c.hosts.has('other.review.invalid'));assert.ok(c.origins.has('https://review.invalid'));assert.deepEqual(c.frameAncestors,['https://modelscope.cn','https://www.modelscope.cn']);
 for(const value of ['*','https://*.modelscope.cn',"'self'",'http://modelscope.cn','https://modelscope.cn/path','https://user:pw@modelscope.cn',"https://modelscope.cn;script-src *"])assert.throws(()=>configure({APP_ORIGIN:'https://review.invalid',APP_FRAME_ANCESTORS:value}));
 assert.throws(()=>configure({APP_FRAME_ANCESTORS:'https://modelscope.cn'}));
});
test('平台内部转发Host仅接受显式的精确值，不扩展浏览器Origin',()=>{
 const c=configure({APP_PROXY_HOSTS:'internal.invalid:7860 localhost'});
 assert.ok(c.hosts.has('internal.invalid:7860'));assert.ok(c.hosts.has('localhost'));
 assert.ok(!c.hosts.has('other.internal.invalid:7860'));assert.ok(!c.origins.has('https://internal.invalid:7860'));
 for(const value of ['*','*.invalid','https://internal.invalid','user:password@host.invalid','host.invalid/path','host.invalid?query=1','host.invalid:0/path'])assert.throws(()=>configure({APP_PROXY_HOSTS:value}));
});
test('显式魔搭代理模式只接受已观测的平台函数域名语法，保持精确浏览器来源',()=>{
 const env={HOST:'0.0.0.0',APP_ORIGIN:'https://review.ms.show',APP_PASSWORD:'nonsecret-test-password',APP_PROXY_MODE:'modelscope'};
 const c=configure(env);assert.ok(c.acceptsHost('studio-review-abcdefgh.cn-beijing-vpc.fcapp.run'));
 for(const host of ['evil.invalid','evil.cn-beijing-vpc.fcapp.run','studio-test.cn-beijing.fcapp.run','studio-test.cn-beijing-vpc.fcapp.run.evil.invalid','studio-test.cn-beijing-vpc.fcapp.run:444'])assert.equal(c.acceptsHost(host),false);
 assert.ok(!c.origins.has('https://studio-review-abcdefgh.cn-beijing-vpc.fcapp.run'));
 assert.ok(!configure({}).acceptsHost('studio-review-abcdefgh.cn-beijing-vpc.fcapp.run'));
 for(const change of [{APP_ORIGIN:'https://review.invalid'},{HOST:'127.0.0.1'},{APP_PROXY_MODE:'any'}])assert.throws(()=>configure({...env,...change}));
});
